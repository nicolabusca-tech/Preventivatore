"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

type DiscountCode = {
  id: string;
  code: string;
  description: string | null;
  discountPercent: number;
  maxUses: number | null;
  usedCount: number;
  expiresAt: string | null;
  active: boolean;
  createdAt: string;
};

export default function AdminCodiciScontoPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [codes, setCodes] = useState<DiscountCode[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  // Form nuovo codice
  const [newCode, setNewCode] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [newPercent, setNewPercent] = useState(10);
  const [newMaxUses, setNewMaxUses] = useState("");
  const [newExpiresAt, setNewExpiresAt] = useState("");
  const [formError, setFormError] = useState("");

  useEffect(() => {
    if (status === "loading") return;
    if (!session || session.user.role !== "admin") {
      router.push("/preventivi");
      return;
    }
    fetchCodes();
  }, [session, status]);

  async function fetchCodes() {
    setLoading(true);
    const res = await fetch("/api/discount-codes");
    const data = await res.json();
    setCodes(data);
    setLoading(false);
  }

  async function handleCreate() {
    setFormError("");
    if (!newCode || !newPercent) {
      setFormError("Codice e percentuale obbligatori");
      return;
    }
    const res = await fetch("/api/discount-codes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: newCode,
        description: newDescription || null,
        discountPercent: newPercent,
        maxUses: newMaxUses ? parseInt(newMaxUses) : null,
        expiresAt: newExpiresAt || null,
      }),
    });
    if (res.ok) {
      setNewCode("");
      setNewDescription("");
      setNewPercent(10);
      setNewMaxUses("");
      setNewExpiresAt("");
      setShowForm(false);
      fetchCodes();
    } else {
      const data = await res.json();
      setFormError(data.error || "Errore");
    }
  }

  async function toggleActive(c: DiscountCode) {
    await fetch(`/api/discount-codes/${c.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ active: !c.active }),
    });
    fetchCodes();
  }

  async function deleteCode(c: DiscountCode) {
    if (!confirm(`Cancellare il codice "${c.code}"?`)) return;
    await fetch(`/api/discount-codes/${c.id}`, { method: "DELETE" });
    fetchCodes();
  }

  function formatDate(d: string | null) {
    if (!d) return "—";
    return new Date(d).toLocaleDateString("it-IT");
  }

  if (status === "loading" || loading) {
    return <div className="text-center py-12 text-mc-muted">Caricamento...</div>;
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-4xl mb-1">Codici sconto</h1>
          <p className="text-mc-muted italic">
            Codici manuali da usare in trattativa (es. AMICO-15, BLACKFRIDAY-20). Sostituiscono lo sconto
            volume automatico.
          </p>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="btn-primary">
          {showForm ? "Annulla" : "+ Nuovo codice"}
        </button>
      </div>

      {showForm && (
        <div className="card p-6 mb-6 bg-orange-50">
          <h2 className="text-xl mb-4">Nuovo codice sconto</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="label">Codice (sarà convertito in maiuscolo)</label>
              <input
                type="text"
                className="input"
                value={newCode}
                onChange={(e) => setNewCode(e.target.value.toUpperCase())}
                placeholder="es. AMICO-15"
              />
            </div>
            <div>
              <label className="label">Sconto (%)</label>
              <input
                type="number"
                className="input"
                value={newPercent}
                onChange={(e) => setNewPercent(parseInt(e.target.value) || 0)}
                min="1"
                max="50"
              />
            </div>
            <div className="md:col-span-2">
              <label className="label">Descrizione (note interne)</label>
              <input
                type="text"
                className="input"
                value={newDescription}
                onChange={(e) => setNewDescription(e.target.value)}
                placeholder="es. Promo amici/conoscenze, validità 30gg"
              />
            </div>
            <div>
              <label className="label">Numero massimo utilizzi (vuoto = illimitato)</label>
              <input
                type="number"
                className="input"
                value={newMaxUses}
                onChange={(e) => setNewMaxUses(e.target.value)}
                placeholder="es. 10"
                min="1"
              />
            </div>
            <div>
              <label className="label">Scadenza (vuoto = nessuna)</label>
              <input
                type="date"
                className="input"
                value={newExpiresAt}
                onChange={(e) => setNewExpiresAt(e.target.value)}
              />
            </div>
          </div>
          {formError && <p className="text-mc-red text-sm mt-2">{formError}</p>}
          <button onClick={handleCreate} className="btn-primary mt-4">
            Crea codice
          </button>
        </div>
      )}

      {codes.length === 0 ? (
        <div className="card p-12 text-center">
          <p className="text-mc-muted italic">Nessun codice sconto creato.</p>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <table className="w-full">
            <thead className="bg-mc-beige-warm">
              <tr>
                <th className="text-left px-4 py-3 text-sm font-semibold">Codice</th>
                <th className="text-left px-4 py-3 text-sm font-semibold">Sconto</th>
                <th className="text-left px-4 py-3 text-sm font-semibold">Descrizione</th>
                <th className="text-left px-4 py-3 text-sm font-semibold">Utilizzi</th>
                <th className="text-left px-4 py-3 text-sm font-semibold">Scadenza</th>
                <th className="text-left px-4 py-3 text-sm font-semibold">Stato</th>
                <th className="text-right px-4 py-3 text-sm font-semibold">Azioni</th>
              </tr>
            </thead>
            <tbody>
              {codes.map((c) => (
                <tr key={c.id} className="border-t border-mc-border">
                  <td className="px-4 py-3 font-mono font-semibold">{c.code}</td>
                  <td className="px-4 py-3 text-mc-green font-semibold">-{c.discountPercent}%</td>
                  <td className="px-4 py-3 text-sm">{c.description || "—"}</td>
                  <td className="px-4 py-3 text-sm">
                    {c.usedCount}
                    {c.maxUses ? ` / ${c.maxUses}` : ""}
                  </td>
                  <td className="px-4 py-3 text-sm">{formatDate(c.expiresAt)}</td>
                  <td className="px-4 py-3">
                    <span className={`badge ${c.active ? "badge-accepted" : "badge-expired"}`}>
                      {c.active ? "Attivo" : "Disattivato"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right text-sm">
                    <button
                      onClick={() => toggleActive(c)}
                      className="text-mc-orange hover:underline mr-3"
                    >
                      {c.active ? "Disattiva" : "Attiva"}
                    </button>
                    <button onClick={() => deleteCode(c)} className="text-mc-red hover:underline">
                      Elimina
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
