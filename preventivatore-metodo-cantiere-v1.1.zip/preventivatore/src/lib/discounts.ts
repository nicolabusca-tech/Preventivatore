// =============================================================================
// LIBRERIA CALCOLO SCONTI - Logica centrale del preventivatore
// 
// Strategia (decisa con Nicola):
// - UN SOLO sconto applicato per preventivo, MAI cumulati
// - Si applica il MIGLIORE sconto applicabile in questo ordine di priorità:
//   1. Codice sconto manuale (se inserito) - SOSTITUISCE tutto
//   2. Sconto bundle automatico (se composti tutti i moduli di un bundle) - SUGGERITO ma applicato dal commerciale
//   3. Sconto volume:
//      - 5+ moduli setup = -10%
//      - 3-4 moduli setup = -5%
//      - <3 moduli setup = nessuno sconto
//
// Sconto annuale CRM 20%: si applica SOLO ai canoni CRM, NON agli altri canoni
// =============================================================================

export type Product = {
  id: string;
  code: string;
  name: string;
  block: string;
  type: string;
  price: number;
  isMonthly: boolean;
  bundleItems: string | null;
};

export type SelectedItem = {
  code: string;
  qty: number;
  price: number;
  isMonthly: boolean;
  block: string;
};

export type DiscountResult = {
  type: "none" | "volume_5" | "volume_10" | "manual";
  percent: number;
  amount: number;
  label: string;
};

export type BundleSuggestion = {
  bundleCode: string;
  bundleName: string;
  bundlePrice: number;
  itemsToReplace: string[]; // codes dei moduli da sostituire
  currentSum: number; // somma attuale dei singoli
  savings: number;
};

// =============================================================================
// CALCOLO SCONTO VOLUMICO
// Conta solo i moduli SETUP (non canoni mensili) per applicare lo sconto
// =============================================================================
export function calcolaScontoVolume(items: SelectedItem[]): DiscountResult {
  // Considera solo voci di setup (non canoni mensili)
  const setupItems = items.filter((i) => !i.isMonthly);
  const totaleSetup = setupItems.reduce((sum, i) => sum + i.price * i.qty, 0);
  const numeroModuli = setupItems.reduce((sum, i) => sum + i.qty, 0);

  if (numeroModuli >= 5) {
    return {
      type: "volume_10",
      percent: 10,
      amount: Math.round(totaleSetup * 0.1),
      label: "Sconto volume 10% (5+ moduli)",
    };
  }
  if (numeroModuli >= 3) {
    return {
      type: "volume_5",
      percent: 5,
      amount: Math.round(totaleSetup * 0.05),
      label: "Sconto volume 5% (3+ moduli)",
    };
  }
  return { type: "none", percent: 0, amount: 0, label: "" };
}

// =============================================================================
// RILEVAMENTO BUNDLE - suggerisce di sostituire moduli singoli con bundle
// Esempio: se l'utente ha selezionato m0301, m0302, m0303, m0304, m0306
// suggerisce di sostituire con BUNDLE_ACQUISIZIONE
// =============================================================================
export function rilevaBundleSuggeriti(
  items: SelectedItem[],
  products: Product[]
): BundleSuggestion[] {
  const selectedCodes = new Set(items.map((i) => i.code));
  const suggerimenti: BundleSuggestion[] = [];

  // Trova tutti i bundle disponibili
  const bundles = products.filter((p) => p.type === "bundle" && p.bundleItems);

  for (const bundle of bundles) {
    const bundleItems = JSON.parse(bundle.bundleItems!) as string[];

    // Verifica se l'utente ha selezionato TUTTI i moduli di questo bundle
    // E NON ha già selezionato il bundle stesso
    if (selectedCodes.has(bundle.code)) continue;

    const allSelected = bundleItems.every((code) => selectedCodes.has(code));
    if (!allSelected) continue;

    // Calcola la somma attuale dei singoli moduli
    const currentSum = bundleItems.reduce((sum, code) => {
      const item = items.find((i) => i.code === code);
      return sum + (item ? item.price * item.qty : 0);
    }, 0);

    const savings = currentSum - bundle.price;
    if (savings <= 0) continue; // bundle non conviene, salta

    suggerimenti.push({
      bundleCode: bundle.code,
      bundleName: bundle.name,
      bundlePrice: bundle.price,
      itemsToReplace: bundleItems,
      currentSum,
      savings,
    });
  }

  return suggerimenti;
}

// =============================================================================
// APPLICAZIONE CODICE SCONTO MANUALE
// Validato lato server con check su tabella DiscountCode
// =============================================================================
export function applicaCodiceManuale(
  totaleSetup: number,
  discountPercent: number,
  code: string
): DiscountResult {
  const amount = Math.round(totaleSetup * (discountPercent / 100));
  return {
    type: "manual",
    percent: discountPercent,
    amount,
    label: `Codice sconto "${code}" (-${discountPercent}%)`,
  };
}

// =============================================================================
// CALCOLO TOTALE PREVENTIVO
// Logica centrale: applica sconti, calcola annuale con sconto CRM 20% se previsto
// =============================================================================
export type TotaliCalcolati = {
  setupBeforeDiscount: number; // setup PRIMA dello sconto
  setupAfterDiscount: number;  // setup DOPO lo sconto applicato
  monthlyTotal: number;        // somma di tutti i canoni mensili
  monthlyCrm: number;          // solo canoni CRM (per applicare sconto 20%)
  monthlyOther: number;        // canoni non-CRM (NESSUNO sconto annuale)
  annualCrmWithDiscount: number; // canoni CRM annuali (con sconto 20% se previsto)
  annualOther: number;         // canoni non-CRM x 12
  annualTotal: number;         // totale primo anno: setup + crm annuale + altri canoni x12
  scontoCrmAnnuale: number;    // sconto risparmiato sui canoni CRM
  voucherAuditScalato: number; // €147 scalati se voucher applicato
};

export function calcolaTotali(
  items: SelectedItem[],
  discount: DiscountResult,
  scontoCrmAnnualeAttivo: boolean,
  voucherAuditApplicato: boolean
): TotaliCalcolati {
  // Setup
  const setupItems = items.filter((i) => !i.isMonthly);
  const setupBeforeDiscount = setupItems.reduce((sum, i) => sum + i.price * i.qty, 0);
  const setupAfterDiscount = Math.max(0, setupBeforeDiscount - discount.amount);

  // Voucher Audit Lampo: scala €147 dalla Diagnosi Strategica se entrambi presenti
  // Logica: se cliente ha Audit Lampo (€147) e ora prende Diagnosi Strategica (€497),
  // i €147 vengono scalati dal totale setup
  const voucherAuditScalato = voucherAuditApplicato ? 147 : 0;

  const setupFinal = Math.max(0, setupAfterDiscount - voucherAuditScalato);

  // Canoni mensili: separa CRM da altri (per applicare correttamente sconto 20% annuale)
  const monthlyItems = items.filter((i) => i.isMonthly);
  const monthlyCrm = monthlyItems
    .filter((i) => i.block === "CANONI_CRM")
    .reduce((sum, i) => sum + i.price, 0); // solo prezzo unitario, no qty
  const monthlyOther = monthlyItems
    .filter((i) => i.block !== "CANONI_CRM")
    .reduce((sum, i) => sum + i.price, 0);
  const monthlyTotal = monthlyCrm + monthlyOther;

  // Annuale: canoni CRM con sconto 20% SE attivato, altri canoni x12 SENZA sconto
  const annualCrmFull = monthlyCrm * 12;
  const annualCrmWithDiscount = scontoCrmAnnualeAttivo
    ? Math.round(annualCrmFull * 0.8) // sconto 20%
    : annualCrmFull;
  const scontoCrmAnnuale = scontoCrmAnnualeAttivo ? Math.round(annualCrmFull * 0.2) : 0;

  const annualOther = monthlyOther * 12;
  const annualTotal = setupFinal + annualCrmWithDiscount + annualOther;

  return {
    setupBeforeDiscount,
    setupAfterDiscount: setupFinal,
    monthlyTotal,
    monthlyCrm,
    monthlyOther,
    annualCrmWithDiscount,
    annualOther,
    annualTotal,
    scontoCrmAnnuale,
    voucherAuditScalato,
  };
}

// Formattazione euro standard
export function formatEuro(value: number): string {
  return new Intl.NumberFormat("it-IT", {
    style: "currency",
    currency: "EUR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}
